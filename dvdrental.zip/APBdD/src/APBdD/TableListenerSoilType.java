/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package APBdD;

import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import javax.swing.table.TableModel;

/**
 *
 * @author rnavarro
 */
public class TableListenerSoilType implements TableModelListener  {
    
    private final Database db;
    
    public TableListenerSoilType(Database d) {
        super();
        db = d;
    }

    @Override
    public void tableChanged(TableModelEvent event) {
        JDBCTableAdpater modelo = (JDBCTableAdpater) event.getSource();        
       
        int row = event.getFirstRow();
        int column = event.getColumn();
        int type = event.getType();
        
        //No se puede modificar una clave primaria
        if( column == 0  ) {
            return;
        }      
        
        String colName = modelo.getColumnName(column);
        String colSQLName = modelo.getSQLColumnName(column);
        String valor=(String)modelo.getValueAt(row,column);
        int tipopk=modelo.getSQLColumnType(0);
        int tipodato=modelo.getSQLColumnType(column);
        String sql;
        if (valor.isEmpty()){
            sql=String.format("UPDATE soil_type SET %s=NULL WHERE soil_type_code=%s", 
                    colSQLName,modelo.getValueAt(row, 0));
            try{
                db.update(sql);
            }catch(SQLException ex){
                System.out.println(ex.getMessage());
            }
        }
        else{
        switch (tipopk) {
            case 4:
                switch (tipodato) {
                    case 4:
                        sql = String.format(
                            "UPDATE soil_type SET %s = %s WHERE soil_type_code = %s",
                            colSQLName,
                            modelo.getValueAt(row, column),
                            modelo.getValueAt(row, 0));
                        break;
                    case 12:
                        sql = String.format(
                            "UPDATE soil_type SET %s = \'%s\' WHERE soil_type_code = \'%s\'",
                            colSQLName,
                            modelo.getValueAt(row, column),
                            modelo.getValueAt(row, 0));
                        break;
                    default:
                        throw new AssertionError();
                }
                break;
            case 12:
                switch (tipodato) {
                    case 4:
                        sql = String.format(
                        "UPDATE soil_type SET %s = %s WHERE soil_type_code = \'%s\'",
                        colSQLName,
                        modelo.getValueAt(row, column),
                        modelo.getValueAt(row, 0));
                        break;
                    case 12:
                        sql = String.format(
                        "UPDATE soil_type SET %s = \'%s\' WHERE soil_type_code = \'%s\'",
                        colSQLName,
                        modelo.getValueAt(row, column),
                        modelo.getValueAt(row, 0));
                        
                        break;
                    default:
                        throw new AssertionError();
                }
                break;
            default:
                throw new AssertionError();
        }
        
        try {
            db.update(sql);
        } catch (SQLException ex) {           
            System.out.println(ex.getMessage());
        }
        System.out.println(sql);
        }
    }
    
    
}
